# Practica 2 de modelado
En esta practica se implementaron los patrones de
diseño Decorator y Adapter a través de la simulación
de un restaurante en linea donde se pueden pedir pizzas y sandwiches
Donde las pizzas necesitaban ser adaptadas al sistema ya implementado para los sandwiches
Arroyo Lozano Santiago - 317150700
Gonzalez Dominguez Saul Fernando - 420003722
